const dgram = require('dgram');

// STUN Receiver Client
// Listens on a UDP port and can receive messages from sender
// Also discovers its own public address by querying the STUN server

const RECEIVER_PORT = 3480;
const STUN_SERVER_HOST = 'localhost'; // Change to server IP if on different machine
const STUN_SERVER_PORT = 3478;

const STUN_MESSAGE_TYPE = {
  BINDING_REQUEST: 0x0001
};

const STUN_MAGIC_COOKIE = 0x2112A442;

// Create receiver socket
const receiver = dgram.createSocket('udp4');

// Helper to create STUN binding request for discovering public address
function createStunBindingRequest() {
  const crypto = require('crypto');
  const message = Buffer.alloc(20);

  message.writeUInt16BE(STUN_MESSAGE_TYPE.BINDING_REQUEST, 0);
  message.writeUInt16BE(0, 2);
  message.writeUInt32BE(STUN_MAGIC_COOKIE, 4);

  const transactionId = crypto.randomBytes(12);
  transactionId.copy(message, 8);

  return { message, transactionId };
}

// Parse STUN response to get mapped address
function parseStunResponse(buffer) {
  if (buffer.length < 20) {
    return null;
  }

  const magicCookie = buffer.readUInt32BE(4);
  if (magicCookie !== STUN_MAGIC_COOKIE) {
    return null;
  }

  // Parse attributes (starting at offset 20)
  let attrOffset = 20;
  const messageLength = buffer.readUInt16BE(2);

  while (attrOffset < buffer.length && attrOffset < 20 + messageLength) {
    const attrType = buffer.readUInt16BE(attrOffset);
    const attrLength = buffer.readUInt16BE(attrOffset + 2);

    // XOR_MAPPED_ADDRESS (0x0020)
    if (attrType === 0x0020 && attrLength >= 8) {
      const family = buffer.readUInt8(attrOffset + 5);

      if (family === 1) { // IPv4
        const xorPort = buffer.readUInt16BE(attrOffset + 6);
        const magicCookieHigh = STUN_MAGIC_COOKIE >> 16;
        const port = xorPort ^ magicCookieHigh;

        const magicCookieBytes = Buffer.alloc(4);
        magicCookieBytes.writeUInt32BE(STUN_MAGIC_COOKIE, 0);

        const addressBytes = [];
        for (let i = 0; i < 4; i++) {
          addressBytes.push(buffer.readUInt8(attrOffset + 8 + i) ^ magicCookieBytes[i]);
        }

        const address = addressBytes.join('.');
        return { address, port };
      }
    }

    // MAPPED_ADDRESS (0x0001)
    if (attrType === 0x0001 && attrLength >= 8) {
      const family = buffer.readUInt8(attrOffset + 5);

      if (family === 1) { // IPv4
        const port = buffer.readUInt16BE(attrOffset + 6);
        const addressBytes = [];
        for (let i = 0; i < 4; i++) {
          addressBytes.push(buffer.readUInt8(attrOffset + 8 + i));
        }
        const address = addressBytes.join('.');
        return { address, port };
      }
    }

    attrOffset += 4 + attrLength;
    if (attrLength % 4 !== 0) {
      attrOffset += 4 - (attrLength % 4);
    }
  }

  return null;
}

// Function to discover public address
function discoverPublicAddress() {
  console.log(`\n[Receiver] Querying STUN server for public address...\n`);

  const client = dgram.createSocket('udp4');
  const { message } = createStunBindingRequest();

  const timeout = setTimeout(() => {
    console.log('[Receiver] STUN query timeout');
    client.close();
  }, 5000);

  client.on('message', (msg) => {
    clearTimeout(timeout);
    const result = parseStunResponse(msg);

    if (result) {
      console.log(`[Receiver] ✓ Public Address: ${result.address}:${result.port}\n`);
    }

    client.close();
  });

  client.on('error', (err) => {
    console.log('[Receiver] STUN query error:', err.message);
    client.close();
  });

  client.send(message, 0, message.length, STUN_SERVER_PORT, STUN_SERVER_HOST, (err) => {
    if (err) {
      console.error('[Receiver] Error sending STUN request:', err);
      client.close();
    }
  });
}

// Receiver event listeners
receiver.on('message', (msg, rinfo) => {
  console.log(`\n[Receiver] Received data from ${rinfo.address}:${rinfo.port}:`);
  console.log(`[Receiver] Message: ${msg.toString()}`);
  console.log(`[Receiver] Message length: ${msg.length} bytes\n`);
});

receiver.on('error', (err) => {
  console.error('[Receiver] Socket error:', err);
  receiver.close();
  process.exit(1);
});

receiver.on('listening', () => {
  const address = receiver.address();
  console.log(`\n[Receiver] Listening on ${address.address}:${address.port}`);
  console.log('[Receiver] Waiting for incoming messages...\n');

  // Discover public address
  discoverPublicAddress();
});

// Bind to receiver port
receiver.bind(RECEIVER_PORT, '0.0.0.0');

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[Receiver] Shutting down...');
  receiver.close();
  process.exit(0);
});
