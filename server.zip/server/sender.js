const dgram = require('dgram');
const crypto = require('crypto');

// STUN Sender Client
// Sends STUN binding requests to discover public IP address

const STUN_SERVER_HOST = 'localhost'; // Change to server IP if on different machine
const STUN_SERVER_PORT = 3478;
const CLIENT_PORT = 3479;

const STUN_MESSAGE_TYPE = {
  BINDING_REQUEST: 0x0001
};

const STUN_MAGIC_COOKIE = 0x2112A442;

// Helper function to create STUN binding request
function createStunBindingRequest() {
  // STUN message header: 20 bytes
  const message = Buffer.alloc(20);

  // Message Type: BINDING_REQUEST (0x0001)
  message.writeUInt16BE(STUN_MESSAGE_TYPE.BINDING_REQUEST, 0);

  // Message Length: 0 (no attributes for this simple implementation)
  message.writeUInt16BE(0, 2);

  // Magic Cookie
  message.writeUInt32BE(STUN_MAGIC_COOKIE, 4);

  // Transaction ID: 12 random bytes
  const transactionId = crypto.randomBytes(12);
  transactionId.copy(message, 8);

  return { message, transactionId };
}

// Helper function to parse STUN response
function parseStunResponse(buffer, sentTransactionId) {
  if (buffer.length < 20) {
    console.log('[Sender] Invalid response: too short');
    return null;
  }

  const messageType = buffer.readUInt16BE(0);
  const messageLength = buffer.readUInt16BE(2);
  const magicCookie = buffer.readUInt32BE(4);
  const transactionId = buffer.slice(8, 20);

  console.log(`[Sender] Response message type: 0x${messageType.toString(16)}`);
  console.log(`[Sender] Message length: ${messageLength}`);

  // Verify transaction ID
  if (!transactionId.equals(sentTransactionId)) {
    console.log('[Sender] Transaction ID mismatch');
    return null;
  }

  // Verify magic cookie
  if (magicCookie !== STUN_MAGIC_COOKIE) {
    console.log('[Sender] Magic cookie mismatch');
    return null;
  }

  // Parse attributes (starting at offset 20)
  let attrOffset = 20;
  while (attrOffset < buffer.length && attrOffset < 20 + messageLength) {
    const attrType = buffer.readUInt16BE(attrOffset);
    const attrLength = buffer.readUInt16BE(attrOffset + 2);

    console.log(`[Sender] Attribute Type: 0x${attrType.toString(16)}, Length: ${attrLength}`);

    // XOR_MAPPED_ADDRESS (0x0020)
    if (attrType === 0x0020 && attrLength >= 8) {
      const family = buffer.readUInt8(attrOffset + 5); // Skip padding byte

      if (family === 1) { // IPv4
        // Get XOR port and address
        const xorPort = buffer.readUInt16BE(attrOffset + 6);
        const magicCookieHigh = STUN_MAGIC_COOKIE >> 16;
        const port = xorPort ^ magicCookieHigh;

        // Get XOR address
        const magicCookieBytes = Buffer.alloc(4);
        magicCookieBytes.writeUInt32BE(STUN_MAGIC_COOKIE, 0);

        const addressBytes = [];
        for (let i = 0; i < 4; i++) {
          addressBytes.push(buffer.readUInt8(attrOffset + 8 + i) ^ magicCookieBytes[i]);
        }

        const address = addressBytes.join('.');
        console.log(`[Sender] Mapped Address: ${address}:${port}`);
        return { address, port };
      }
    }

    // MAPPED_ADDRESS (0x0001) - fallback for older servers
    if (attrType === 0x0001 && attrLength >= 8) {
      const family = buffer.readUInt8(attrOffset + 5);

      if (family === 1) { // IPv4
        const port = buffer.readUInt16BE(attrOffset + 6);
        const addressBytes = [];
        for (let i = 0; i < 4; i++) {
          addressBytes.push(buffer.readUInt8(attrOffset + 8 + i));
        }
        const address = addressBytes.join('.');
        console.log(`[Sender] Mapped Address (non-XOR): ${address}:${port}`);
        return { address, port };
      }
    }

    attrOffset += 4 + attrLength;
    // Align to 4-byte boundary
    if (attrLength % 4 !== 0) {
      attrOffset += 4 - (attrLength % 4);
    }
  }

  return null;
}

// Create UDP client
const client = dgram.createSocket('udp4');

// Send initial binding request
function sendBindingRequest() {
  console.log(`\n[Sender] Sending STUN Binding Request to ${STUN_SERVER_HOST}:${STUN_SERVER_PORT}\n`);

  const { message, transactionId } = createStunBindingRequest();

  client.send(message, 0, message.length, STUN_SERVER_PORT, STUN_SERVER_HOST, (err) => {
    if (err) {
      console.error('[Sender] Error sending request:', err);
      client.close();
      process.exit(1);
    }
  });

  // Set timeout for response
  setTimeout(() => {
    console.log('[Sender] No response received from server');
    client.close();
    process.exit(1);
  }, 5000);
}

client.on('message', (msg, rinfo) => {
  console.log(`\n[Sender] Received response from ${rinfo.address}:${rinfo.port}`);
  const result = parseStunResponse(msg, Buffer.alloc(12)); // In real scenario, match transaction ID
  
  if (result) {
    console.log(`\n[Sender] ✓ Your Public Address: ${result.address}:${result.port}\n`);
  } else {
    console.log('[Sender] Failed to parse response');
  }

  client.close();
  process.exit(0);
});

client.on('error', (err) => {
  console.error('[Sender] Client error:', err);
  process.exit(1);
});

client.on('listening', () => {
  const address = client.address();
  console.log(`[Sender] Client listening on ${address.address}:${address.port}`);
  sendBindingRequest();
});

// Bind to a specific port
client.bind(CLIENT_PORT, '0.0.0.0');

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[Sender] Shutting down...');
  client.close();
  process.exit(0);
});
