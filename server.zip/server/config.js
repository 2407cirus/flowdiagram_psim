// Configuration file for STUN server and clients
// Modify these values to customize the server behavior

module.exports = {
  // STUN Server Configuration
  server: {
    host: '0.0.0.0',           // Bind to all interfaces
    port: 3478,                // Standard STUN port
    enableLogging: true        // Enable detailed logging
  },

  // Sender Client Configuration
  sender: {
    serverHost: 'localhost',   // STUN server address
    serverPort: 3478,          // STUN server port
    clientPort: 3479,          // Local sender port
    requestTimeout: 5000       // Timeout in milliseconds
  },

  // Receiver Client Configuration
  receiver: {
    port: 3480,                // Local receiver listening port
    serverHost: 'localhost',   // STUN server address for discovery
    serverPort: 3478,          // STUN server port
    requestTimeout: 5000       // Timeout for STUN query
  },

  // STUN Protocol Constants (RFC 5389)
  stun: {
    magicCookie: 0x2112A442,
    messageTypes: {
      BINDING_REQUEST: 0x0001,
      BINDING_RESPONSE: 0x0101,
      BINDING_ERROR_RESPONSE: 0x0111
    },
    attributes: {
      MAPPED_ADDRESS: 0x0001,
      RESPONSE_ADDRESS: 0x0002,
      CHANGE_REQUEST: 0x0003,
      SOURCE_ADDRESS: 0x0004,
      CHANGED_ADDRESS: 0x0005,
      USERNAME: 0x0006,
      PASSWORD: 0x0007,
      MESSAGE_INTEGRITY: 0x0008,
      ERROR_CODE: 0x0009,
      UNKNOWN_ATTRIBUTES: 0x000A,
      REFLECTED_FROM: 0x000B,
      REALM: 0x0014,
      NONCE: 0x0015,
      XOR_MAPPED_ADDRESS: 0x0020
    }
  }
};
