const dgram = require('dgram');

// STUN Server Implementation
// Listens for STUN binding requests and responds with client's IP and port

const STUN_PORT = 3478;
const server = dgram.createSocket('udp4');

// STUN Message Type Constants
const STUN_MESSAGE_TYPE = {
  BINDING_REQUEST: 0x0001,
  BINDING_RESPONSE: 0x0101,
  BINDING_ERROR_RESPONSE: 0x0111
};

// STUN Attribute Constants
const STUN_ATTRIBUTES = {
  MAPPED_ADDRESS: 0x0001,
  RESPONSE_ADDRESS: 0x0002,
  CHANGE_REQUEST: 0x0003,
  SOURCE_ADDRESS: 0x0004,
  CHANGED_ADDRESS: 0x0005,
  USERNAME: 0x0006,
  PASSWORD: 0x0007,
  MESSAGE_INTEGRITY: 0x0008,
  ERROR_CODE: 0x0009,
  UNKNOWN_ATTRIBUTES: 0x000A,
  REFLECTED_FROM: 0x000B,
  REALM: 0x0014,
  NONCE: 0x0015,
  XOR_MAPPED_ADDRESS: 0x0020
};

// STUN Magic Cookie
const STUN_MAGIC_COOKIE = 0x2112A442;

// Helper function to parse STUN message
function parseStunMessage(buffer) {
  if (buffer.length < 20) {
    return null;
  }

  const messageType = buffer.readUInt16BE(0);
  const messageLength = buffer.readUInt16BE(2);
  const magicCookie = buffer.readUInt32BE(4);

  if (magicCookie !== STUN_MAGIC_COOKIE) {
    return null;
  }

  return {
    type: messageType,
    length: messageLength,
    transactionId: buffer.slice(8, 20)
  };
}

// Helper function to create STUN response
function createStunResponse(transactionId, remoteAddress, remotePort) {
  // Create STUN response message
  const messageType = STUN_MESSAGE_TYPE.BINDING_RESPONSE;
  const messageLength = 12; // XOR_MAPPED_ADDRESS attribute (12 bytes)

  const response = Buffer.alloc(20 + messageLength);

  // Write message type
  response.writeUInt16BE(messageType, 0);

  // Write message length
  response.writeUInt16BE(messageLength, 2);

  // Write magic cookie
  response.writeUInt32BE(STUN_MAGIC_COOKIE, 4);

  // Write transaction ID
  transactionId.copy(response, 8);

  // Add XOR_MAPPED_ADDRESS attribute
  let attrOffset = 20;

  // Attribute type: XOR_MAPPED_ADDRESS
  response.writeUInt16BE(STUN_ATTRIBUTES.XOR_MAPPED_ADDRESS, attrOffset);
  attrOffset += 2;

  // Attribute length: 8 bytes (for IPv4: family (2) + port (2) + address (4))
  response.writeUInt16BE(8, attrOffset);
  attrOffset += 2;

  // Address family (1 = IPv4)
  response.writeUInt8(0, attrOffset);
  attrOffset += 1;
  response.writeUInt8(1, attrOffset);
  attrOffset += 1;

  // XOR port (XOR with magic cookie)
  const xorPort = remotePort ^ (STUN_MAGIC_COOKIE >> 16);
  response.writeUInt16BE(xorPort, attrOffset);
  attrOffset += 2;

  // XOR address (XOR each octet with magic cookie bytes)
  const addressParts = remoteAddress.split('.').map(x => parseInt(x, 10));
  const magicCookieBytes = Buffer.alloc(4);
  magicCookieBytes.writeUInt32BE(STUN_MAGIC_COOKIE, 0);

  for (let i = 0; i < 4; i++) {
    response.writeUInt8(addressParts[i] ^ magicCookieBytes[i], attrOffset);
    attrOffset += 1;
  }

  return response;
}

// Server event listeners
server.on('message', (msg, rinfo) => {
  console.log(`\n[STUN Server] Received message from ${rinfo.address}:${rinfo.port}`);

  const stunMsg = parseStunMessage(msg);

  if (!stunMsg) {
    console.log('[STUN Server] Invalid STUN message');
    return;
  }

  if (stunMsg.type !== STUN_MESSAGE_TYPE.BINDING_REQUEST) {
    console.log('[STUN Server] Received non-binding-request message');
    return;
  }

  console.log('[STUN Server] Processing STUN Binding Request');
  console.log(`[STUN Server] Client Address: ${rinfo.address}:${rinfo.port}`);

  // Create and send response
  const response = createStunResponse(stunMsg.transactionId, rinfo.address, rinfo.port);
  server.send(response, 0, response.length, rinfo.port, rinfo.address, (err) => {
    if (err) {
      console.log('[STUN Server] Error sending response:', err);
    } else {
      console.log('[STUN Server] Response sent successfully');
    }
  });
});

server.on('error', (err) => {
  console.error('[STUN Server] Error:', err);
  server.close();
});

server.on('listening', () => {
  const address = server.address();
  console.log(`\n[STUN Server] Listening on ${address.address}:${address.port}`);
  console.log('[STUN Server] Waiting for STUN binding requests...\n');
});

server.on('close', () => {
  console.log('[STUN Server] Server closed');
});

// Start listening
server.bind(STUN_PORT, '0.0.0.0');

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n[STUN Server] Shutting down...');
  server.close();
  process.exit(0);
});
