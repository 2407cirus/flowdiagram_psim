# STUN Server Architecture & Documentation

## Overview

This project implements a complete STUN (Session Traversal Utilities for NAT) server system with sender and receiver clients. STUN is essential for applications that need to establish P2P connections through NAT firewalls.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     Network Diagram                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─────────────────┐         ┌──────────────────┐           │
│  │  NAT Gateway    │         │  STUN Server     │           │
│  │  (Firewall)     │         │  0.0.0.0:3478    │           │
│  └────────┬────────┘         └────────┬─────────┘           │
│           │                          │                      │
│           ├──────────────────────────┼────────────────────-─│
│           │                          │                      │
│  ┌────────▼──────────┐    ┌──────────▼────────────┐         │
│  │  Sender Client    │    │  Receiver Client     │         │
│  │  Localhost:3481   │    │  Localhost:3482      │         │
│  │  (Behind NAT)     │    │  (Behind NAT)        │         │
│  └───────────────────┘    └──────────────────────┘         │
│           │                          │                      │
│           └──────────────────────────┘                      │
│          Direct P2P Communication (learned via STUN)        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## How STUN Works

### Step 1: Sender Discovers Public Address
```
Sender                         STUN Server
  │
  ├─ STUN Binding Request ───────────>
  │  [Message Type: 0x0001]
  │  [Transaction ID: random 12 bytes]
  │
  <─────── STUN Binding Response ─────
  │  [Message Type: 0x0101]
  │  [Attribute: XOR-MAPPED-ADDRESS]
  │  [IP: 127.0.0.1, Port: 3481]
  │
  Sender discovers: 127.0.0.1:3481 (public address)
```

### Step 2: Receiver Discovers Public Address
```
Receiver                       STUN Server
  │
  ├─ STUN Binding Request ───────────>
  │
  <─────── STUN Binding Response ─────
  │  [IP: 127.0.0.1, Port: 3482]
  │
  Receiver discovers: 127.0.0.1:3482 (public address)
```

### Step 3: Direct P2P Communication
```
Sender (knows Receiver's public address)    Receiver
  │
  ├─ Custom Data Message ────────────────────────>
  │  Can now send directly using discovered address
  │
```

## File Structure

### Core Files

1. **stun-server.js** (85 lines)
   - UDP server listening on port 3478
   - Parses STUN binding requests
   - Responds with client's public IP and port
   - Uses XOR-MAPPED-ADDRESS attribute (RFC 5389)

2. **sender.js** (140 lines)
   - Sends STUN binding request to server
   - Parses response to get public address
   - Example of client-side STUN implementation
   - Listens on port 3479

3. **receiver.js** (145 lines)
   - Listens for incoming messages (port 3480)
   - Queries STUN server for public address discovery
   - Ready to receive data from sender

4. **advanced-p2p.js** (280 lines)
   - Advanced implementation with bidirectional messaging
   - Sender and Receiver classes
   - Interactive CLI for sending messages
   - Demonstrates P2P communication

### Supporting Files

5. **package.json**
   - Project metadata
   - NPM scripts for running components

6. **config.js**
   - Centralized configuration
   - Port definitions
   - STUN constants and attributes

7. **test-suite.js**
   - Comprehensive testing suite
   - 5 major test categories
   - Performance benchmarking
   - Validates server responses

8. **README.md**
   - User-friendly documentation
   - Quick start guide
   - STUN protocol explanation

## STUN Message Format (RFC 5389)

### Request Message (20 bytes minimum)
```
 0                   1                   2                   3
 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|      BINDING REQUEST (0x0001)      |        Message Length      |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                  STUN Magic Cookie (0x2112A442)               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                                                               |
|                    Transaction ID (12 bytes)                  |
|                                                               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
[Optional Attributes]
```

### Response Message
```
Sample Response with XOR-MAPPED-ADDRESS:

Header (20 bytes):
  Message Type: 0x0101 (Binding Response)
  Message Length: 12 bytes (for one attribute)
  Magic Cookie: 0x2112A442
  Transaction ID: [echo of request]

Attribute (16 bytes):
  Type: 0x0020 (XOR-MAPPED-ADDRESS)
  Length: 8 bytes
  Reserved: 0x00
  Address Family: 0x01 (IPv4)
  XOR-Port: [port XOR'd with magic cookie]
  XOR-Address: [IP XOR'd with magic cookie]
```

## STUN Attributes Used

| Attribute | Type | Length | Purpose |
|-----------|------|--------|---------|
| MAPPED-ADDRESS | 0x0001 | 8+ | Client's mapped IP and port |
| XOR-MAPPED-ADDRESS | 0x0020 | 8+ | Like MAPPED-ADDRESS but XOR'd for privacy |
| BINDING-REQUEST | 0x0001 | - | Request message type |
| BINDING-RESPONSE | 0x0101 | - | Response message type |

## Protocol State Machine

### Server State Machine
```
         START
           │
           ├─ Listen on UDP:3478
           │
    ┌──────▼──────────┐
    │ Waiting for     │
    │ Requests        │◄──────┐
    └──────┬──────────┘       │
           │                  │
           ├─ Receive STUN ────┤
           │ Request           │
           │                   │
    ┌──────▼──────────┐       │
    │ Parse Message   │       │
    │ Validate        │       │
    └──────┬──────────┘       │
           │                  │
    ┌──────▼──────────┐       │
    │ Extract Client  │       │
    │ IP:Port         │       │
    └──────┬──────────┘       │
           │                  │
    ┌──────▼──────────┐       │
    │ Create Response │       │
    │ with Attributes │       │
    └──────┬──────────┘       │
           │                  │
    ┌──────▼──────────┐       │
    │ Send Response   │───────┴─
    │ to Client       │
    └────────────────┘
```

## Security Considerations

### Current Implementation
- No authentication (messages are public)
- No encryption (messages are plaintext)
- No message integrity checking

### Production Improvements
1. **Add Authentication**
   - Use USERNAME/PASSWORD attributes (RFC 5389)
   - Implement MESSAGE-INTEGRITY attribute
   - Use long-term credentials

2. **Add Encryption**
   - Use DTLS (Datagram TLS) for transport security
   - Encrypt application data after address discovery

3. **Rate Limiting**
   - Limit requests per IP address
   - Implement request throttling
   - Detect and block flood attacks

4. **Logging & Monitoring**
   - Log suspicious activities
   - Monitor response times
   - Track client statistics

## Performance Characteristics

### Expected Performance
- Single request/response: < 5ms (localhost)
- Throughput: 1000+ requests/second
- Memory footprint: ~10MB for server
- Concurrent clients: 10,000+

### Scalability
- Single-threaded Node.js event loop
- Non-blocking UDP I/O
- Stateless design (no connection tracking)
- Can scale with clustering for multiple cores

## NAT Traversal Scenarios

### Scenario 1: Symmetric NAT (Most Restrictive)
- Requires explicit IP:port mapping from STUN
- Same external IP for all destinations
- Cannot be bypassed with standard STUN alone
- Solution: Use TURN server (Traversal Using Relays around NAT)

### Scenario 2: Cone NAT (Common)
- Full Cone: Single external IP:port pair
- Address-Restricted Cone: Same IP:port for same IP (different ports allowed)
- Port-Restricted Cone: Same IP:port for exact same IP:port pair
- Solution: STUN alone is sufficient for direct communication

### Scenario 3: Public IP (No NAT)
- No address translation needed
- Sender and Receiver already have public addresses
- STUN provides confirmation of public address

## Testing

### Run Test Suite
```bash
# Start server first
node stun-server.js

# In another terminal, run tests
node test-suite.js
```

### What Tests Check
1. ✓ Server responds to STUN requests
2. ✓ Response format is valid
3. ✓ Mapped address is extracted correctly
4. ✓ Multiple sequential requests work
5. ✓ Performance benchmarks (< 5ms per request)

## Troubleshooting

### Issue: "EADDRINUSE" error
**Cause**: Port already in use
**Solution**: Change port in config or kill process using the port
```bash
# Windows - find process using port 3478
netstat -ano | findstr :3478
taskkill /PID <PID> /F

# Linux/Mac
lsof -i :3478
kill -9 <PID>
```

### Issue: No response from server
**Cause**: Firewall blocking UDP traffic
**Solution**: 
- Check firewall rules allow UDP on port 3478
- Test on localhost first
- Ensure server is running

### Issue: Wrong IP address returned
**Cause**: Incorrect XOR calculation or address parsing
**Solution**: 
- Enable logging to debug
- Check network configuration
- Verify magic cookie is correct (0x2112A442)

## References

- RFC 3489: STUN - Simple Traversal of User Datagram Protocol (UDP) Through Network Address Translators (NATs)
- RFC 5389: Session Traversal Utilities for NAT (STUN)
- RFC 5766: Traversal Using Relays around NAT (TURN)
- RFC 8489: Session Traversal Utilities for NAT (STUN) - Obsoletes RFC 5389

## Future Enhancements

1. **TURN Protocol Support**
   - Implement relay server for symmetric NAT cases
   - Add media relay capabilities

2. **IPv6 Support**
   - Handle IPv6 addresses
   - Dual-stack STUN server

3. **Metrics & Analytics**
   - Collect statistics on client connections
   - Monitor response times and errors
   - Generate reports

4. **Web Dashboard**
   - Visual monitoring of server status
   - Real-time statistics
   - Client connection tracking

5. **Clustering**
   - Load balancing across multiple servers
   - Geographic distribution
   - High availability setup

## License

ISC

---

**Last Updated**: 2026-04-22
**Version**: 1.0.0
