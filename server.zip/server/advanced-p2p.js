const dgram = require('dgram');

// Advanced STUN Sender/Receiver with P2P messaging capability
// This demonstrates bidirectional communication between sender and receiver

const config = {
  senderPort: 3481,
  receiverPort: 3482,
  stunServerHost: 'localhost',
  stunServerPort: 3478,
  messageBuffer: []
};

const STUN_MAGIC_COOKIE = 0x2112A442;
const STUN_MESSAGE_TYPE = {
  BINDING_REQUEST: 0x0001
};

// ==================== Sender ====================
class AdvancedSender {
  constructor() {
    this.socket = dgram.createSocket('udp4');
    this.publicAddress = null;
    this.publicPort = null;
  }

  start() {
    console.log('\n========== ADVANCED SENDER ==========\n');

    this.socket.on('listening', () => {
      const addr = this.socket.address();
      console.log(`[AdvSender] Listening on ${addr.address}:${addr.port}`);
      this.discoverPublicAddress();
    });

    this.socket.on('message', (msg, rinfo) => {
      console.log(`[AdvSender] Received from ${rinfo.address}:${rinfo.port}`);
      console.log(`[AdvSender] Message: "${msg.toString()}"`);
    });

    this.socket.on('error', (err) => {
      console.error('[AdvSender] Error:', err);
    });

    this.socket.bind(config.senderPort);
  }

  discoverPublicAddress() {
    console.log('[AdvSender] Discovering public address via STUN...\n');

    const client = dgram.createSocket('udp4');
    const request = this.createStunRequest();

    const timeout = setTimeout(() => {
      console.log('[AdvSender] STUN discovery timeout');
      client.close();
    }, 5000);

    client.on('message', (msg) => {
      clearTimeout(timeout);
      const result = this.parseStunResponse(msg);

      if (result) {
        this.publicAddress = result.address;
        this.publicPort = result.port;
        console.log(`[AdvSender] ✓ Public Address: ${this.publicAddress}:${this.publicPort}\n`);
        console.log('[AdvSender] Ready to send messages');
        console.log('[AdvSender] Commands:');
        console.log('  - send <receiver-ip> <message>  (send message to receiver)');
        console.log('  - info                          (show public address)');
        console.log('  - quit                          (exit)\n');
      }

      client.close();
    });

    client.send(request, 0, request.length, config.stunServerPort, config.stunServerHost);
  }

  sendMessageTo(receiverHost, receiverPort, message) {
    const msgBuffer = Buffer.from(message);
    this.socket.send(msgBuffer, 0, msgBuffer.length, receiverPort, receiverHost, (err) => {
      if (err) {
        console.log(`[AdvSender] Error sending message: ${err}`);
      } else {
        console.log(`[AdvSender] Message sent to ${receiverHost}:${receiverPort}`);
      }
    });
  }

  createStunRequest() {
    const crypto = require('crypto');
    const message = Buffer.alloc(20);
    message.writeUInt16BE(STUN_MESSAGE_TYPE.BINDING_REQUEST, 0);
    message.writeUInt16BE(0, 2);
    message.writeUInt32BE(STUN_MAGIC_COOKIE, 4);
    crypto.randomBytes(12).copy(message, 8);
    return message;
  }

  parseStunResponse(buffer) {
    if (buffer.length < 20) return null;

    const magicCookie = buffer.readUInt32BE(4);
    if (magicCookie !== STUN_MAGIC_COOKIE) return null;

    let attrOffset = 20;
    const messageLength = buffer.readUInt16BE(2);

    while (attrOffset < buffer.length && attrOffset < 20 + messageLength) {
      const attrType = buffer.readUInt16BE(attrOffset);
      const attrLength = buffer.readUInt16BE(attrOffset + 2);

      if (attrType === 0x0020 && attrLength >= 8) { // XOR_MAPPED_ADDRESS
        const family = buffer.readUInt8(attrOffset + 5);
        if (family === 1) {
          const xorPort = buffer.readUInt16BE(attrOffset + 6);
          const port = xorPort ^ (STUN_MAGIC_COOKIE >> 16);

          const magicCookieBytes = Buffer.alloc(4);
          magicCookieBytes.writeUInt32BE(STUN_MAGIC_COOKIE, 0);

          const addressBytes = [];
          for (let i = 0; i < 4; i++) {
            addressBytes.push(buffer.readUInt8(attrOffset + 8 + i) ^ magicCookieBytes[i]);
          }

          return { address: addressBytes.join('.'), port };
        }
      }

      attrOffset += 4 + attrLength;
      if (attrLength % 4 !== 0) {
        attrOffset += 4 - (attrLength % 4);
      }
    }

    return null;
  }

  close() {
    this.socket.close();
  }
}

// ==================== Receiver ====================
class AdvancedReceiver {
  constructor() {
    this.socket = dgram.createSocket('udp4');
    this.publicAddress = null;
    this.publicPort = null;
  }

  start() {
    console.log('\n========== ADVANCED RECEIVER ==========\n');

    this.socket.on('listening', () => {
      const addr = this.socket.address();
      console.log(`[AdvReceiver] Listening on ${addr.address}:${addr.port}\n`);
      this.discoverPublicAddress();
    });

    this.socket.on('message', (msg, rinfo) => {
      console.log(`\n[AdvReceiver] Message from ${rinfo.address}:${rinfo.port}`);
      console.log(`[AdvReceiver] Content: "${msg.toString()}"`);
      console.log(`[AdvReceiver] Time: ${new Date().toLocaleTimeString()}\n`);
    });

    this.socket.on('error', (err) => {
      console.error('[AdvReceiver] Error:', err);
    });

    this.socket.bind(config.receiverPort);
  }

  discoverPublicAddress() {
    console.log('[AdvReceiver] Discovering public address via STUN...\n');

    const client = dgram.createSocket('udp4');
    const request = this.createStunRequest();

    const timeout = setTimeout(() => {
      console.log('[AdvReceiver] STUN discovery timeout');
      client.close();
    }, 5000);

    client.on('message', (msg) => {
      clearTimeout(timeout);
      const result = this.parseStunResponse(msg);

      if (result) {
        this.publicAddress = result.address;
        this.publicPort = result.port;
        console.log(`[AdvReceiver] ✓ Public Address: ${this.publicAddress}:${this.publicPort}`);
        console.log(`[AdvReceiver] ✓ Listening on local port ${config.receiverPort}\n`);
        console.log('[AdvReceiver] Waiting for incoming messages...\n');
      }

      client.close();
    });

    client.send(request, 0, request.length, config.stunServerPort, config.stunServerHost);
  }

  createStunRequest() {
    const crypto = require('crypto');
    const message = Buffer.alloc(20);
    message.writeUInt16BE(STUN_MESSAGE_TYPE.BINDING_REQUEST, 0);
    message.writeUInt16BE(0, 2);
    message.writeUInt32BE(STUN_MAGIC_COOKIE, 4);
    crypto.randomBytes(12).copy(message, 8);
    return message;
  }

  parseStunResponse(buffer) {
    if (buffer.length < 20) return null;

    const magicCookie = buffer.readUInt32BE(4);
    if (magicCookie !== STUN_MAGIC_COOKIE) return null;

    let attrOffset = 20;
    const messageLength = buffer.readUInt16BE(2);

    while (attrOffset < buffer.length && attrOffset < 20 + messageLength) {
      const attrType = buffer.readUInt16BE(attrOffset);
      const attrLength = buffer.readUInt16BE(attrOffset + 2);

      if (attrType === 0x0020 && attrLength >= 8) { // XOR_MAPPED_ADDRESS
        const family = buffer.readUInt8(attrOffset + 5);
        if (family === 1) {
          const xorPort = buffer.readUInt16BE(attrOffset + 6);
          const port = xorPort ^ (STUN_MAGIC_COOKIE >> 16);

          const magicCookieBytes = Buffer.alloc(4);
          magicCookieBytes.writeUInt32BE(STUN_MAGIC_COOKIE, 0);

          const addressBytes = [];
          for (let i = 0; i < 4; i++) {
            addressBytes.push(buffer.readUInt8(attrOffset + 8 + i) ^ magicCookieBytes[i]);
          }

          return { address: addressBytes.join('.'), port };
        }
      }

      attrOffset += 4 + attrLength;
      if (attrLength % 4 !== 0) {
        attrOffset += 4 - (attrLength % 4);
      }
    }

    return null;
  }

  close() {
    this.socket.close();
  }
}

// ==================== CLI Handler ====================
function startInteractiveMode() {
  const readline = require('readline');

  const mode = process.argv[2] || 'both';

  let sender = null;
  let receiver = null;

  if (mode === 'sender' || mode === 'both') {
    sender = new AdvancedSender();
    sender.start();
  }

  if (mode === 'receiver' || mode === 'both') {
    receiver = new AdvancedReceiver();
    receiver.start();
  }

  if (mode === 'sender' && sender) {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });

    rl.on('line', (input) => {
      const parts = input.trim().split(' ');
      const command = parts[0];

      if (command === 'send' && parts.length >= 3) {
        const host = parts[1];
        const message = parts.slice(2).join(' ');
        sender.sendMessageTo(host, config.receiverPort, message);
      } else if (command === 'info') {
        console.log(`Public Address: ${sender.publicAddress}:${sender.publicPort}`);
      } else if (command === 'quit') {
        sender.close();
        rl.close();
        process.exit(0);
      } else {
        console.log('Commands: send <host> <message> | info | quit');
      }
    });
  }

  process.on('SIGINT', () => {
    console.log('\n\nShutting down...');
    if (sender) sender.close();
    if (receiver) receiver.close();
    process.exit(0);
  });
}

// Start the application
if (require.main === module) {
  startInteractiveMode();
}

module.exports = { AdvancedSender, AdvancedReceiver };
