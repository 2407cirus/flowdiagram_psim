# STUN Server Implementation

A complete implementation of a STUN (Session Traversal Utilities for NAT) server with sender and receiver clients for NAT traversal and IP address discovery.

## What is STUN?

STUN is a network protocol that allows applications to discover their public IP address and determine the type of NAT they are behind. This is essential for peer-to-peer communication in applications like VoIP, video conferencing, and online gaming.

## Project Structure

- **stun-server.js** - STUN server that listens for binding requests and responds with client's public IP and port
- **sender.js** - Client that sends STUN binding requests to discover its public address
- **receiver.js** - Client that listens for incoming messages and also queries STUN server for its public address
- **package.json** - Project dependencies and scripts

## Features

### STUN Server
- Listens on UDP port 3478 (standard STUN port)
- Parses STUN binding requests
- Returns client's public IP address and port
- Supports XOR-MAPPED-ADDRESS attribute (RFC 5389)
- Handles transaction IDs for request tracking

### Sender Client
- Sends STUN binding requests to the server
- Receives and parses STUN responses
- Displays the discovered public IP address and port
- Uses UDP port 3479

### Receiver Client
- Listens on UDP port 3480 for incoming messages
- Queries STUN server to discover its own public address
- Can receive data from other clients on its listening port

## Prerequisites

- Node.js (v12 or higher)

## Installation

No external dependencies needed - uses Node.js built-in `dgram` module for UDP communication.

## Usage

### Terminal 1: Start the STUN Server

```bash
npm run start-server
# or
node stun-server.js
```

Expected output:
```
[STUN Server] Listening on 0.0.0.0:3478
[STUN Server] Waiting for STUN binding requests...
```

### Terminal 2: Run the Sender Client

```bash
npm run start-sender
# or
node sender.js
```

Expected output:
```
[Sender] Client listening on 0.0.0.0:3479
[Sender] Sending STUN Binding Request to localhost:3478

[Sender] Received response from localhost:3478
[Sender] Response message type: 0x101
[Sender] Message length: 12
[Sender] Attribute Type: 0x20, Length: 8
[Sender] Mapped Address: 127.0.0.1:3479

[Sender] ✓ Your Public Address: 127.0.0.1:3479
```

### Terminal 3: Run the Receiver Client

```bash
npm run start-receiver
# or
node receiver.js
```

Expected output:
```
[Receiver] Listening on 0.0.0.0:3480
[Receiver] Waiting for incoming messages...

[Receiver] Querying STUN server for public address...

[Receiver] ✓ Public Address: 127.0.0.1:3480
```

## STUN Message Format

### Binding Request (from client)
```
0                   1                   2                   3
0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|     BINDING REQUEST (0x0001)  |         Message Length        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                     STUN Magic Cookie                         |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                    Transaction ID (12 bytes)                  |
|                                       +-+-+-+-+-+-+-+-+-+-+-+-+
|                                       |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
```

### Binding Response (from server)
```
Same format as binding request, but includes:
- Message Type: 0x0101 (Binding Response)
- Attributes like MAPPED-ADDRESS or XOR-MAPPED-ADDRESS
```

## Attribution

This STUN implementation is based on RFC 3489 (classic STUN) and RFC 5389 (STUN v2) specifications.

## Testing Remotely

To test between different machines:

1. Update `STUN_SERVER_HOST` in sender.js and receiver.js to point to your server machine's IP
2. Update STUN server binding address if needed
3. Ensure firewall allows UDP traffic on ports 3478, 3479, and 3480

Example:
```javascript
// In sender.js and receiver.js
const STUN_SERVER_HOST = '192.168.1.100'; // Server's IP address
```

## Customization

### Change Ports

Edit the port constants in each file:
- stun-server.js: `STUN_PORT`
- sender.js: `STUN_SERVER_PORT`, `CLIENT_PORT`
- receiver.js: `RECEIVER_PORT`, `STUN_SERVER_PORT`

### Add Authentication

Implement USERNAME/PASSWORD attributes or MESSAGE-INTEGRITY for secure requests.

### Add More Attributes

Extend the STUN parser to handle additional attributes like:
- REALM (0x0014)
- NONCE (0x0015)
- ERROR-CODE (0x0009)

## License

ISC
