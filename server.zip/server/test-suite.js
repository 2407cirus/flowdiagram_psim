const dgram = require('dgram');
const crypto = require('crypto');

/**
 * STUN Testing Suite
 * Validates STUN server responses and client functionality
 */

const STUN_SERVER_HOST = 'localhost';
const STUN_SERVER_PORT = 3478;
const STUN_MAGIC_COOKIE = 0x2112A442;
const STUN_MESSAGE_TYPE = {
  BINDING_REQUEST: 0x0001,
  BINDING_RESPONSE: 0x0101
};

let testsRun = 0;
let testsPassed = 0;
let testsFailed = 0;

// Test utilities
function createStunRequest() {
  const message = Buffer.alloc(20);
  message.writeUInt16BE(STUN_MESSAGE_TYPE.BINDING_REQUEST, 0);
  message.writeUInt16BE(0, 2);
  message.writeUInt32BE(STUN_MAGIC_COOKIE, 4);
  crypto.randomBytes(12).copy(message, 8);
  return message;
}

function logTest(testName, passed, details = '') {
  testsRun++;
  if (passed) {
    testsPassed++;
    console.log(`  ✓ ${testName}`);
  } else {
    testsFailed++;
    console.log(`  ✗ ${testName}`);
    if (details) console.log(`    ${details}`);
  }
}

function logSection(title) {
  console.log(`\n${title}`);
  console.log('='.repeat(title.length));
}

// Test 1: Check server connectivity
async function testServerConnectivity() {
  return new Promise((resolve) => {
    logSection('Test 1: Server Connectivity');

    const client = dgram.createSocket('udp4');
    const message = createStunRequest();
    let responseReceived = false;

    const timeout = setTimeout(() => {
      client.close();
      logTest(
        'Server responds to STUN request',
        responseReceived,
        'No response received within 5 seconds'
      );
      resolve();
    }, 5000);

    client.on('message', (msg, rinfo) => {
      responseReceived = true;
      clearTimeout(timeout);
      client.close();
      logTest('Server responds to STUN request', true);
      resolve();
    });

    client.on('error', (err) => {
      clearTimeout(timeout);
      client.close();
      logTest('Server connectivity', false, `Error: ${err.message}`);
      resolve();
    });

    client.send(message, 0, message.length, STUN_SERVER_PORT, STUN_SERVER_HOST, (err) => {
      if (err) {
        clearTimeout(timeout);
        logTest('Send STUN request', false, `Error: ${err.message}`);
        resolve();
      }
    });
  });
}

// Test 2: Validate STUN response format
async function testResponseFormat() {
  return new Promise((resolve) => {
    logSection('Test 2: Response Format Validation');

    const client = dgram.createSocket('udp4');
    const message = createStunRequest();

    const timeout = setTimeout(() => {
      client.close();
      logTest('Receive valid STUN response', false, 'Timeout');
      resolve();
    }, 5000);

    client.on('message', (msg, rinfo) => {
      clearTimeout(timeout);

      try {
        // Check minimum length (20 bytes header + attributes)
        logTest('Response length >= 20 bytes', msg.length >= 20, `Length: ${msg.length}`);

        // Check message type (should be 0x0101 for binding response)
        const messageType = msg.readUInt16BE(0);
        logTest(
          'Response message type is BINDING_RESPONSE (0x0101)',
          messageType === STUN_MESSAGE_TYPE.BINDING_RESPONSE,
          `Type: 0x${messageType.toString(16)}`
        );

        // Check magic cookie
        const magicCookie = msg.readUInt32BE(4);
        logTest(
          'Magic cookie is correct',
          magicCookie === STUN_MAGIC_COOKIE,
          `Cookie: 0x${magicCookie.toString(16)}`
        );

        // Check message length field
        const messageLength = msg.readUInt16BE(2);
        logTest(
          'Message length field is valid',
          messageLength >= 8 && messageLength <= msg.length - 20,
          `Length: ${messageLength}`
        );

        // Verify transaction ID exists
        const transactionId = msg.slice(8, 20);
        logTest('Transaction ID present', transactionId.length === 12);
      } catch (err) {
        logTest('Parse response', false, err.message);
      }

      client.close();
      resolve();
    });

    client.send(message, 0, message.length, STUN_SERVER_PORT, STUN_SERVER_HOST);
  });
}

// Test 3: Parse mapped address
async function testMappedAddress() {
  return new Promise((resolve) => {
    logSection('Test 3: Mapped Address Extraction');

    const client = dgram.createSocket('udp4');
    const message = createStunRequest();

    const timeout = setTimeout(() => {
      client.close();
      logTest('Extract mapped address', false, 'Timeout');
      resolve();
    }, 5000);

    client.on('message', (msg, rinfo) => {
      clearTimeout(timeout);

      try {
        let foundMappedAddress = false;

        // Parse attributes
        let attrOffset = 20;
        const messageLength = msg.readUInt16BE(2);

        while (attrOffset < msg.length && attrOffset < 20 + messageLength) {
          const attrType = msg.readUInt16BE(attrOffset);
          const attrLength = msg.readUInt16BE(attrOffset + 2);

          if (attrType === 0x0020) { // XOR_MAPPED_ADDRESS
            foundMappedAddress = true;
            const family = msg.readUInt8(attrOffset + 5);

            if (family === 1) { // IPv4
              const xorPort = msg.readUInt16BE(attrOffset + 6);
              const port = xorPort ^ (STUN_MAGIC_COOKIE >> 16);

              const magicCookieBytes = Buffer.alloc(4);
              magicCookieBytes.writeUInt32BE(STUN_MAGIC_COOKIE, 0);

              const addressBytes = [];
              for (let i = 0; i < 4; i++) {
                addressBytes.push(msg.readUInt8(attrOffset + 8 + i) ^ magicCookieBytes[i]);
              }

              const address = addressBytes.join('.');
              logTest('XOR_MAPPED_ADDRESS found', true);
              logTest('Address is valid IPv4', /^\d+\.\d+\.\d+\.\d+$/.test(address), address);
              logTest('Port is valid', port > 0 && port < 65536, `Port: ${port}`);
            }
            break;
          }

          attrOffset += 4 + attrLength;
          if (attrLength % 4 !== 0) {
            attrOffset += 4 - (attrLength % 4);
          }
        }

        logTest('Mapped address attribute present', foundMappedAddress);
      } catch (err) {
        logTest('Parse mapped address', false, err.message);
      }

      client.close();
      resolve();
    });

    client.send(message, 0, message.length, STUN_SERVER_PORT, STUN_SERVER_HOST);
  });
}

// Test 4: Multiple requests
async function testMultipleRequests() {
  return new Promise((resolve) => {
    logSection('Test 4: Multiple Sequential Requests');

    const requestCount = 3;
    let successCount = 0;

    for (let i = 0; i < requestCount; i++) {
      const client = dgram.createSocket('udp4');
      const message = createStunRequest();

      const timeout = setTimeout(() => {
        client.close();
      }, 2000);

      client.on('message', () => {
        clearTimeout(timeout);
        successCount++;
        client.close();

        if (successCount === requestCount) {
          logTest(
            `Handle ${requestCount} sequential requests`,
            successCount === requestCount,
            `Successful: ${successCount}/${requestCount}`
          );
          resolve();
        }
      });

      client.send(message, 0, message.length, STUN_SERVER_PORT, STUN_SERVER_HOST);
    }
  });
}

// Test 5: Performance test
async function testPerformance() {
  return new Promise((resolve) => {
    logSection('Test 5: Performance');

    const requestCount = 10;
    const startTime = Date.now();
    let completedRequests = 0;

    for (let i = 0; i < requestCount; i++) {
      const client = dgram.createSocket('udp4');
      const message = createStunRequest();

      const timeout = setTimeout(() => {
        client.close();
      }, 5000);

      client.on('message', () => {
        clearTimeout(timeout);
        completedRequests++;
        client.close();

        if (completedRequests === requestCount) {
          const elapsedTime = Date.now() - startTime;
          const avgTime = elapsedTime / requestCount;
          logTest(`Process ${requestCount} requests`, completedRequests === requestCount);
          logTest(
            'Average response time',
            avgTime < 100,
            `${avgTime.toFixed(2)}ms per request (${elapsedTime}ms total)`
          );
          resolve();
        }
      });

      client.send(message, 0, message.length, STUN_SERVER_PORT, STUN_SERVER_HOST);
    }
  });
}

// Main test runner
async function runAllTests() {
  console.log('\n╔════════════════════════════════════════╗');
  console.log('║   STUN Server Testing Suite            ║');
  console.log('║   Target: ' + STUN_SERVER_HOST + ':' + STUN_SERVER_PORT + '                   ║');
  console.log('╚════════════════════════════════════════╝');

  try {
    await testServerConnectivity();
    await testResponseFormat();
    await testMappedAddress();
    await testMultipleRequests();
    await testPerformance();
  } catch (err) {
    console.error('Test error:', err);
  }

  // Summary
  logSection('Test Summary');
  console.log(`Total Tests: ${testsRun}`);
  console.log(`Passed: ${testsPassed} ✓`);
  console.log(`Failed: ${testsFailed} ✗`);
  console.log(`Success Rate: ${((testsPassed / testsRun) * 100).toFixed(1)}%\n`);

  if (testsFailed === 0) {
    console.log('✓ All tests passed!');
    process.exit(0);
  } else {
    console.log('✗ Some tests failed');
    process.exit(1);
  }
}

// Run tests if this is the main module
if (require.main === module) {
  runAllTests().catch(console.error);
}

module.exports = { testServerConnectivity, testResponseFormat, testMappedAddress };
